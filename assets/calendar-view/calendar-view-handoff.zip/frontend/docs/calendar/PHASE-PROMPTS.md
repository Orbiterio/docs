# Calendar View — Phase Prompts

Read BRIEF.md and its addenda first. Each phase below includes the current
implementation additions before its preserved original prompt. All gates are
requirements to prove; this package contains no completed implementation.


---

# Calendar View — Phase 0: Read and plan

[Frontend brief](/guides/open-work/roadmap/calendar-view/frontend/brief) · [Calendar View](/guides/open-work/roadmap/calendar-view) · [Phase 1](/guides/open-work/roadmap/calendar-view/frontend/phase-1)

Inspect the installed TanStack and Temporal APIs, resolve contract gaps, and agree on the calendar file tree before coding.

> This is a future implementation task. The supplied prompt is preserved below; the integration requirements add the decisions and evidence needed to accept it. This documentation does not indicate that the phase has been implemented or measured.

## QA and JEV instructions

Prepend this addendum to the original phase prompt below:

```text
Read docs/calendar/QA-REVIEW.md, docs/calendar/INTEGRATION-GATES.md and
docs/calendar/JEV.md alongside docs/calendar/BRIEF.md.
Account decisions A01/A02 are confirmed: selected-account events/new meetings, cross-account availability over the chosen calendar set. Resolve the trusted account-email/capability adapter and preference persistence; distinguish Orbiter owner changes from local grant selection.
Read docs/calendar/PERFORMANCE.md. Record the test environment, cache limits and eviction policy, cold-load budget, effective nine-slot matrix and P01-P08 before implementation; measure existing baselines where available and mark the rest not run.
Read docs/calendar/AGENDA-AND-SCHEDULING.md. Resolve the contact-search candidate contract, scheduler guest DTO and real Nylas notification/write path; apply the no-scroll month and context-list amendments.
Read docs/calendar/NAVIGATION-AND-CACHE.md. Inspect the existing widget feed and both query keys; plan one shared cache owner, the proposed 60-day forward window, full coverage and snapshot/stream handoff. Resolve G14 and the shared navigation/shortcut state before implementation.
Resolve QA01–QA09 and the existing route/envelope, storage, owner, UUID-context and dependency-version gaps before coding. Assess J01 and J02 independently: record their exact owner/seam, baseline, dataset and acceptance criteria, or defer them. Neither pilot is required for the base calendar. Do not copy the existing outcome router's taxonomy or threshold.
```

The [QA review](/guides/open-work/roadmap/calendar-view/qa-review) and [Akira JEV assessment](/guides/open-work/roadmap/akira/jev) are included in the handoff bundle. The original prompt remains verbatim.

## Shared input extension

Read the separate [NL Date Picker specification](/guides/open-work/roadmap/calendar-view/nl-date-picker) (`docs/calendar/NL-DATE-PICKER.md` in the handoff). Record the shared picker contract, one chosen manual UI adapter and the narrow standalone-picker dependency amendment. This extends the original source brief; inspect installed APIs before selecting packages.

## Paste-ready phase prompt

```text
Read docs/calendar/BRIEF.md in full. Then:
1. List every ambiguity or gap you found, one line each, with your proposed resolution.
2. Propose the file tree under src/features/calendar/ with a one-line purpose per file.
3. Confirm the installed versions of @tanstack/react-db, @tanstack/query-db-collection,
   @tanstack/react-virtual, @tanstack/ai and temporal-polyfill, and list the exact export
   names you will use for collections, live queries, direct writes and mutations.
Do not write application code in this phase. Stop and wait for review.
```

## Integration requirements

- Apply [Agenda and scheduling](/guides/open-work/roadmap/calendar-view/agenda-and-scheduling); its explicit month-navigation, agenda-mode and scheduler requirements supersede conflicting source instructions.
- Apply the [navigation and shared-cache addendum](/guides/open-work/roadmap/calendar-view/navigation-and-cache) and close the phase-specific requirements in [G14](/guides/open-work/roadmap/calendar-view/integration-gates#g14).
- Read the complete brief and integration gates. Inspect the actual frontend repository, installed package versions and `.d.ts` exports; record exact collection, live-query, direct-write, mutation and Akira registration signatures.
- Propose resolutions for missing write schemas, recurring scopes, worker completion, SSE handoff, timezone behavior and existing people/contact hooks. Keep unresolved decisions visible; do not invent API fields.
- Deliver the proposed file tree and an ambiguity log. This phase produces a reviewed plan, with no application implementation.

Read the related gates: [G01](/guides/open-work/roadmap/calendar-view/integration-gates#g01), [G02](/guides/open-work/roadmap/calendar-view/integration-gates#g02), [G06](/guides/open-work/roadmap/calendar-view/integration-gates#g06), [G07](/guides/open-work/roadmap/calendar-view/integration-gates#g07), [G09](/guides/open-work/roadmap/calendar-view/integration-gates#g09).

## Acceptance evidence

Installed versions and type-file locations, exact export signatures, proposed file tree, ambiguity log and review decision.

[Frontend brief](/guides/open-work/roadmap/calendar-view/frontend/brief) · [Phase 1](/guides/open-work/roadmap/calendar-view/frontend/phase-1)


---

# Calendar View — Phase 1: Data layer and fixture

[Phase 0](/guides/open-work/roadmap/calendar-view/frontend/phase-0) · [Calendar View](/guides/open-work/roadmap/calendar-view) · [Phase 2](/guides/open-work/roadmap/calendar-view/frontend/phase-2)

Build deterministic fixtures, live collections, window state, replay and optimistic mutations against the fixed calendar contract.

> This is a future implementation task. The supplied prompt is preserved below; the integration requirements add the decisions and evidence needed to accept it. This documentation does not indicate that the phase has been implemented or measured.

## QA and JEV instructions

Prepend this addendum to the original phase prompt below:

```text
Read docs/calendar/QA-REVIEW.md, docs/calendar/INTEGRATION-GATES.md and
docs/calendar/JEV.md alongside docs/calendar/BRIEF.md.
Preserve one owner-scoped store/stream across active grant switches. Keep coverage for availability-selected calendars across accounts even when hidden from display; no false free gaps or covered-switch refetch.
Apply docs/calendar/PERFORMANCE.md to one shared store, visible-range-first loading, bounded 60-day warm-up, incremental changes and cache retention. Measure requests, payload/ingestion, delta latency and lifecycle counts; do not hide partial coverage.
Read docs/calendar/NAVIGATION-AND-CACHE.md and implement G14 with the data layer. Warm the proposed 60-day forward range, union it with visible-range margins, migrate widget and calendar consumers to one normalized store, and own one stream in the shared session lifecycle. Test more than 50 events per calendar, all-day rows, partial pages, reload/replay and no duplicate feed requests.
Keep the deterministic 5,000-event performance fixture unchanged. If Phase 0 selected a JEV pilot, add a separate synthetic Decisions fixture and disabled/timeout/429/malformed/unknown mocks. No live calendar data or provider calls are needed. Prove JEV cannot alter row identity, sync, cursor state or writes.
```

The [QA review](/guides/open-work/roadmap/calendar-view/qa-review) and [Akira JEV assessment](/guides/open-work/roadmap/akira/jev) are included in the handoff bundle. The original prompt remains verbatim.

## Paste-ready phase prompt

```text
Implement section 3 of docs/calendar/BRIEF.md.
Deliverables:
- fixtures/calendar/generate.ts producing the section 5.1 fixture from a seed, plus an MSW
  handler set that serves the API contract (2.1) from that fixture, including an SSE endpoint
  that emits a scripted sequence of ChangeEvents.
- src/features/calendar/store: window store, calendarsCollection, eventsCollection.
- src/features/calendar/queries.ts: the five hooks in 3.2.
- src/features/calendar/realtime.ts: EventSource lifecycle, since cursor, reconnect, 410 handling.
- src/features/calendar/mutations.ts: collection handlers with optimistic rollback and the
  recurring scope parameter.
- src/features/calendar/layout/packDay.ts with property-based tests (fast-check), written first.
Definition of done:
- vitest green, including a test that navigating inside the window issues zero fetches and one
  that an SSE upsert updates a live query result without a refetch.
- A short REPORT.md: what you verified against the installed types, anything you guessed.
No UI in this phase beyond a scratch page that renders counts.
```

## Integration requirements

- Apply the [navigation and shared-cache addendum](/guides/open-work/roadmap/calendar-view/navigation-and-cache) and close the phase-specific requirements in [G14](/guides/open-work/roadmap/calendar-view/integration-gates#g14).
- Freeze and record the seed, PRNG, anchor date, timezone and generator version. Report a fixture hash and counts for all 5,000 events; the recurring, participant, all-day and multi-day categories may overlap.
- Resolve snapshot/replay ordering and the native EventSource recovery design before claiming gap-free SSE. Test overlapping fetches and SSE updates, duplicate replay, remount/reload, expired cursors and updates that arrive while an optimistic mutation is pending.
- Keep loaded ranges separate from backend coverage. Exercise failed and partial window loads without marking them complete. Zero network requests inside the loaded window must be measured.
- Use approved write DTOs and verified installed collection APIs. Mocks may expose unresolved backend behavior, but must not turn it into a claimed production contract.

Read the related gates: [G03](/guides/open-work/roadmap/calendar-view/integration-gates#g03), [G04](/guides/open-work/roadmap/calendar-view/integration-gates#g04), [G05](/guides/open-work/roadmap/calendar-view/integration-gates#g05), [G06](/guides/open-work/roadmap/calendar-view/integration-gates#g06), [G09](/guides/open-work/roadmap/calendar-view/integration-gates#g09), [G10](/guides/open-work/roadmap/calendar-view/integration-gates#g10).

## Acceptance evidence

Fixture manifest, counts and hash; meaningful Vitest/property tests; raw fetch counts; scripted SSE results; `REPORT.md` naming verified types and remaining assumptions.

[Phase 0](/guides/open-work/roadmap/calendar-view/frontend/phase-0) · [Phase 2](/guides/open-work/roadmap/calendar-view/frontend/phase-2)


---

# Calendar View — Phase 2: Shell, week and day views

[Phase 1](/guides/open-work/roadmap/calendar-view/frontend/phase-1) · [Calendar View](/guides/open-work/roadmap/calendar-view) · [Phase 3](/guides/open-work/roadmap/calendar-view/frontend/phase-3)

Render the quiet calendar shell, packed event columns and timezone-aware day/week views, then measure them.

> This is a future implementation task. The supplied prompt is preserved below; the integration requirements add the decisions and evidence needed to accept it. This documentation does not indicate that the phase has been implemented or measured.

## QA and JEV instructions

Prepend this addendum to the original phase prompt below:

```text
Read docs/calendar/QA-REVIEW.md, docs/calendar/INTEGRATION-GATES.md and
docs/calendar/JEV.md alongside docs/calendar/BRIEF.md.
Add the left-rail Calendar account selector (email/provider/status) and New events in destination. Account switching filters calendar/linked agenda events and defaults future drafts; preserve date/view. Keep identity accessible with a collapsed rail.
Apply docs/calendar/PERFORMANCE.md to covered navigation, render isolation, day packing, code splitting and shortcut dispatch. Report first render, commits, requests and total incremental bundle bytes.
Read docs/calendar/NAVIGATION-AND-CACHE.md and implement its navigation contract: Cmd-K > Navigation > Calendar View, top-left icon switcher, and one 400 ms controller for 0 versus 0 0. Preserve the shared header on the calendar route. Dispatch single-zero to the shared today-agenda action; Phase 3 completes that panel. Test focus exclusions, repeat, timing and no agenda flash on double-zero.
Apply the QA all-day and dependency corrections. No JEV calls belong in the shell, grid, now-line, layout, date conversion or loaded-window navigation. Preserve every rendering and screenshot gate.
```

The [QA review](/guides/open-work/roadmap/calendar-view/qa-review) and [Akira JEV assessment](/guides/open-work/roadmap/akira/jev) are included in the handoff bundle. The original prompt remains verbatim.

## Paste-ready phase prompt

```text
Implement sections 4.1, 4.2 and 4.6 of docs/calendar/BRIEF.md against the Phase 1 data layer
and fixture. Left rail and agenda panel can be empty containers with the correct dimensions
and collapse behavior; the mini month should work.
Rules:
- Grid and chips are absolutely positioned from packDay output. No per-cell components in a
  CSS grid.
- Now-line updates on a 60s interval and on visibility change.
- All time math through Temporal in the user's tz; tests cover DST transition weeks
  (March 8 and November 1, 2026, America/New_York).
Definition of done:
- Playwright screenshots of week and day at both viewport sizes, light and dark.
- React Profiler numbers for: week first render, week navigation, editing a single fixture
  event via the collection (which columns re-rendered).
- Report which of the section 5.2 gates pass and the raw numbers.
- One sentence naming the visual element you removed after reviewing the screenshots.
```

## Integration requirements

- Apply the [navigation and shared-cache addendum](/guides/open-work/roadmap/calendar-view/navigation-and-cache) and close the phase-specific requirements in [G14](/guides/open-work/roadmap/calendar-view/integration-gates#g14).
- Implement the agreed DST behavior for missing and repeated local hours. Use Temporal for range boundaries, all-day dates, overlap and coordinates; do not assume every day lasts 24 hours.
- Use one accent for today's column and the now-line, hairline grid rules, tabular figures and flat event chips. Calendar colors remain subordinate, low-alpha data cues.
- Measure first render, navigation and the columns affected by one event change. A cross-day or multi-day change may invalidate the relevant old and new columns; unrelated days should remain stable.
- Capture week and day at 1440×900 and 1920×1080 in light and dark themes. Review those screenshots and name one visual element actually removed.

Read the related gates: [G08](/guides/open-work/roadmap/calendar-view/integration-gates#g08), [G10](/guides/open-work/roadmap/calendar-view/integration-gates#g10), [G11](/guides/open-work/roadmap/calendar-view/integration-gates#g11).

## Acceptance evidence

DST test results, four viewport/theme combinations for each view, React Profiler measurements and a one-sentence removal critique.

[Phase 1](/guides/open-work/roadmap/calendar-view/frontend/phase-1) · [Phase 3](/guides/open-work/roadmap/calendar-view/frontend/phase-3)


---

# Calendar View — Phase 3: Month view and agenda panel

[Phase 2](/guides/open-work/roadmap/calendar-view/frontend/phase-2) · [Calendar View](/guides/open-work/roadmap/calendar-view) · [Phase 4](/guides/open-work/roadmap/calendar-view/frontend/phase-4)

Add no-scroll month paging, a context-rich agenda List and a visual Timeline with linked selection. The original prompt below is preserved, with the current requirements taking precedence.

> This is a future implementation task. The supplied prompt is preserved below; the integration requirements add the decisions and evidence needed to accept it. This documentation does not indicate that the phase has been implemented or measured.

## QA and JEV instructions

Prepend this addendum to the original phase prompt below:

```text
Read docs/calendar/QA-REVIEW.md, docs/calendar/INTEGRATION-GATES.md and
docs/calendar/JEV.md alongside docs/calendar/BRIEF.md.
Apply confirmed A01/A02: meeting rows come from the active account, free gaps include conflicts across the availability-selected calendars. Show neutral Busy on another calendar intervals in Timeline without adding those meetings to the active-account list.
Apply docs/calendar/PERFORMANCE.md: use its month-paging replacement for source budget slot 5, preserve the other eight limits, and measure warm context List/Timeline open/switch, the explicit 500-record agenda slice and complete-coverage free gaps.
Read docs/calendar/AGENDA-AND-SCHEDULING.md. It supersedes infinite/virtualized month scrolling and the 30-screen month-scroll gate in the preserved prompt: fit 4–6 week rows without scrolling and page by calendar month. Implement context-rich agenda List plus Timeline/open gaps; keep agenda virtualization and its 500-record gate.
Read docs/calendar/NAVIGATION-AND-CACHE.md. Wire single-zero to open the shared agenda on today without leaving the current workspace view. Retain List/Timeline mode and contact/company panel sizing. Derive open-time gaps from complete shared calendar coverage; cancellations do not block time, and incomplete or failed ranges must not appear free.
Use the new all-day-capable adapter and approved UUID context bridge. Keep the agenda chronological and virtualization deterministic. Defer semantic reranking unless an independently approved candidate-pool contract and evaluation justify it; do not add a new endpoint.
```

The [QA review](/guides/open-work/roadmap/calendar-view/qa-review) and [Akira JEV assessment](/guides/open-work/roadmap/akira/jev) are included in the handoff bundle. The original prompt remains verbatim.

## Paste-ready phase prompt

```text
Implement sections 4.3 and 4.5 (list state only) of docs/calendar/BRIEF.md.
- Month rows and the agenda list are virtualized with @tanstack/react-virtual.
- Month view spanning bars for multi-day and all-day events are laid out before single events.
- Agenda rows resolve participant entityIds through the existing people resolver hook;
  unresolved emails render as plain rows. Do not add a new resolver.
- Hover linking between agenda rows and grid chips in both directions.
Definition of done:
- 30-screen month scroll recording with no dropped frames (Playwright trace).
- Agenda mount timing with 500 rows.
- Screenshots as before, plus a critique line.
```

## Integration requirements

- Apply [Agenda and scheduling](/guides/open-work/roadmap/calendar-view/agenda-and-scheduling); its explicit month-navigation, agenda-mode and scheduler requirements supersede conflicting source instructions.
- Apply the [navigation and shared-cache addendum](/guides/open-work/roadmap/calendar-view/navigation-and-cache) and close the phase-specific requirements in [G14](/guides/open-work/roadmap/calendar-view/integration-gates#g14).
- Use the same collections and fixture as the day/week views. Report the count of mounted rows while scrolling and separate virtualized DOM size from the 500 agenda records used for the mount gate.
- Verify multi-day and all-day bars across month and timezone boundaries. Hover and selection must remain coherent when a related row or chip is outside the virtualized viewport.
- Inspect and reuse the existing people resolver. If that hook is absent or incompatible, record the gap before proposing another endpoint or resolver.
- Record month-paging/overflow traces covering four-, five- and six-row months, agenda mount timing, both viewport sizes and both themes. The original 30-screen month-scroll check is superseded. End the visual review with one named removal.

Read the related gates: [G07](/guides/open-work/roadmap/calendar-view/integration-gates#g07), [G08](/guides/open-work/roadmap/calendar-view/integration-gates#g08), [G10](/guides/open-work/roadmap/calendar-view/integration-gates#g10), [G11](/guides/open-work/roadmap/calendar-view/integration-gates#g11).

## Acceptance evidence

Month-paging/overflow trace, frame data, 500-record context-agenda mount timing, mounted-row counts, screenshots and removal critique.

[Phase 2](/guides/open-work/roadmap/calendar-view/frontend/phase-2) · [Phase 4](/guides/open-work/roadmap/calendar-view/frontend/phase-4)


---

# Calendar View — Phase 4: Interactions

[Phase 3](/guides/open-work/roadmap/calendar-view/frontend/phase-3) · [Calendar View](/guides/open-work/roadmap/calendar-view) · [Phase 5](/guides/open-work/roadmap/calendar-view/frontend/phase-5)

Implement drag, resize, quick-create and keyboard controls through the shared optimistic mutation layer.

> This is a future implementation task. The supplied prompt is preserved below; the integration requirements add the decisions and evidence needed to accept it. This documentation does not indicate that the phase has been implemented or measured.

## QA and JEV instructions

Prepend this addendum to the original phase prompt below:

```text
Read docs/calendar/QA-REVIEW.md, docs/calendar/INTEGRATION-GATES.md and
docs/calendar/JEV.md alongside docs/calendar/BRIEF.md.
Bind each draft and mutation to an explicit grant/calendar. New drafts inherit the active destination; changing the rail does not retarget open drafts/in-flight writes. Existing events retain their original identity. Test expired/read-only destinations and cross-account conflicts.
Apply docs/calendar/PERFORMANCE.md to drag frames, isolated form input, scheduler open, guest search and pending feedback. Measure provider confirmation separately; local draft/drag performance must not depend on AI or Nylas.
Read docs/calendar/AGENDA-AND-SCHEDULING.md. Build click/range scheduling with the shared date picker, fuzzy contacts/direct-email guest entry and explicit final event creation/invitation delivery through the approved Go/Nylas command path. Draft changes never send invitations. Verify notification query placement, provider identity, recovery and webhook reconciliation.
Close the ownership, write-schema and attendee-targeting gaps before reusing legacy mutations. Pointer, keyboard, read-only state, recurring scope and rollback stay deterministic. A JEV verdict never authorizes a write or changes the user-selected scope.
```

The [QA review](/guides/open-work/roadmap/calendar-view/qa-review) and [Akira JEV assessment](/guides/open-work/roadmap/akira/jev) are included in the handoff bundle. The original prompt remains verbatim.

## Shared input extension

Read the separate [NL Date Picker specification](/guides/open-work/roadmap/calendar-view/nl-date-picker) (`docs/calendar/NL-DATE-PICKER.md` in the handoff). Quick-create may use the shared picker after its temporal core and manual controls pass. Text interpretation only updates a draft; the existing event Save action owns the mutation. Keep the base calendar usable with manual fields while the extension is unfinished.

## Paste-ready phase prompt

```text
Implement section 4.4 of docs/calendar/BRIEF.md and the recurring scope dialog from 3.4.
- Drag and resize use pointer events on the column, a ghost element moved with transform,
  and a single collection mutation on pointerup. Prove zero React commits during drag with a
  Profiler recording.
- 15-minute snap. Cross-day drag in week view.
- Quick-create popover with the attendee typeahead using the existing contacts search hook.
- Full keyboard map from 4.4 with a visible focus ring on the selected chip.
- Optimistic failure path: MSW returns 500 for one PATCH; the chip snaps back and a toast
  offers retry.
Definition of done:
- Playwright tests: drag-move, resize, drag-create, keyboard navigation, failure rollback,
  recurring scope dialog appears only for events with masterEventId.
- Drag frame timing under 4x CPU throttle.
```

## Integration requirements

- Apply [Agenda and scheduling](/guides/open-work/roadmap/calendar-view/agenda-and-scheduling); its explicit month-navigation, agenda-mode and scheduler requirements supersede conflicting source instructions.
- Finalize mutation bodies, recurring-scope semantics and conflict handling before exercising writes. Respect read-only events and calendars through pointer, keyboard and mutation entry points.
- Handle pointer cancellation, lost capture and Escape without committing a ghost edit. Test DST transitions, cross-day moves, all-day boundaries and failure rollback after a newer SSE change.
- Keep text inputs safe from global single-letter shortcuts. Restore focus after popovers and dialogs close; preserve visible keyboard selection in virtualized views.
- Prove zero React commits during the drag interval and report frame timing at 4× CPU throttle. Include interaction screenshots at both viewport sizes in light and dark, plus one named removal.

Read the related gates: [G06](/guides/open-work/roadmap/calendar-view/integration-gates#g06), [G07](/guides/open-work/roadmap/calendar-view/integration-gates#g07), [G08](/guides/open-work/roadmap/calendar-view/integration-gates#g08), [G10](/guides/open-work/roadmap/calendar-view/integration-gates#g10), [G11](/guides/open-work/roadmap/calendar-view/integration-gates#g11).

## Acceptance evidence

Playwright interaction and failure cases, Profiler recording, raw drag timings, screenshots and removal critique.

[Phase 3](/guides/open-work/roadmap/calendar-view/frontend/phase-3) · [Phase 5](/guides/open-work/roadmap/calendar-view/frontend/phase-5)


---

# Calendar View — Phase 5: Event detail and Orbiter context

[Phase 4](/guides/open-work/roadmap/calendar-view/frontend/phase-4) · [Calendar View](/guides/open-work/roadmap/calendar-view) · [Phase 6](/guides/open-work/roadmap/calendar-view/frontend/phase-6)

Connect event details to existing Orbiter contact context without extending the fixed API silently.

> This is a future implementation task. The supplied prompt is preserved below; the integration requirements add the decisions and evidence needed to accept it. This documentation does not indicate that the phase has been implemented or measured.

## QA and JEV instructions

Prepend this addendum to the original phase prompt below:

```text
Read docs/calendar/QA-REVIEW.md, docs/calendar/INTEGRATION-GATES.md and
docs/calendar/JEV.md alongside docs/calendar/BRIEF.md.
Apply docs/calendar/PERFORMANCE.md to deferred/batched meeting context, stable person-ID caches and details loaded on demand. No per-event request waterfall or model dependency may block the agenda or scheduler.
Read docs/calendar/AGENDA-AND-SCHEDULING.md. Use supported meeting/relationship context in the agenda List as well as event detail. Editing reuses the scheduler and preserves selected guest identities/emails. Never synthesize missing context or attendee acceptance.
Apply QA04 and QA08 before reusing relationship or RSVP hooks. If the approved per-claim source contract exists, add J02 only in shadow mode at the context adapter; preserve baseline display and record supported/contradicted/insufficient with source versions. If that evidence is absent, defer J02 explicitly. Do not generate facts or resolve people with JEV.
```

The [QA review](/guides/open-work/roadmap/calendar-view/qa-review) and [Akira JEV assessment](/guides/open-work/roadmap/akira/jev) are included in the handoff bundle. The original prompt remains verbatim.

## Shared input extension

Read the separate [NL Date Picker specification](/guides/open-work/roadmap/calendar-view/nl-date-picker) (`docs/calendar/NL-DATE-PICKER.md` in the handoff). Reuse the same picker for event-detail time edits. Preserve read-only, recurrence-scope and mutation rules; new NL suggestions cannot overwrite a newer manual edit or imply event-save success.

## Paste-ready phase prompt

```text
Implement the detail state of the agenda panel (section 4.5).
- Participants render as Orbiter people cards using the existing entityId resolver and the
  "How I know X" narrative hook. Unresolved emails get an "Add to Orbiter" action that calls
  the existing contact-create flow.
- The conferencing join button becomes the primary action within 15 minutes of start.
- Inline edit reuses the quick-create fields; delete goes through the scope dialog for series.
Definition of done:
- Screenshots of detail for: a 1:1 with a resolved contact, a 6-person meeting with two
  unresolved emails, an all-day event, a read-only event.
- No new data fetching hooks; everything comes from the collections plus the existing
  people resolver.
```

## Integration requirements

- Apply [Agenda and scheduling](/guides/open-work/roadmap/calendar-view/agenda-and-scheduling); its explicit month-navigation, agenda-mode and scheduler requirements supersede conflicting source instructions.
- Interpret the supplied prompt's 'people cards' as reusable participant content rendered in flat rows, consistent with the brief's no-cards direction.
- Inspect the existing entity resolver, relationship narrative and contact-create flow. Report missing or incompatible hooks; do not invent a replacement data source.
- Location and conferencing are optional DTO fields that the supplied Go adapter does not yet populate. Notes and RSVP writes lack contracts in the new brief; an older RSVP API exists but needs the approved ownership/identity adapter from QA08. Keep these gaps explicit and do not claim unsupported actions work.
- Capture the four requested detail scenarios at both viewport sizes in light and dark. Check focus, read-only controls and the join-button timing; name one element removed.

Read the related gates: [G06](/guides/open-work/roadmap/calendar-view/integration-gates#g06), [G07](/guides/open-work/roadmap/calendar-view/integration-gates#g07), [G11](/guides/open-work/roadmap/calendar-view/integration-gates#g11).

## Acceptance evidence

Resolved/unresolved participant cases, read-only and all-day detail screenshots, hook reuse references, join-timing checks and removal critique.

[Phase 4](/guides/open-work/roadmap/calendar-view/frontend/phase-4) · [Phase 6](/guides/open-work/roadmap/calendar-view/frontend/phase-6)


---

# Calendar View — Phase 6: Akira tools

[Phase 5](/guides/open-work/roadmap/calendar-view/frontend/phase-5) · [Calendar View](/guides/open-work/roadmap/calendar-view) · [Phase 7](/guides/open-work/roadmap/calendar-view/frontend/phase-7)

The proposed tool scope now lives in [Akira — Calendar capability](/guides/open-work/roadmap/akira/calendar). **Akira is spec only, not implemented.** The inspected scoped chat registry is a reuse candidate; it is not a functioning Akira calendar registry. This integration phase depends on Akira's runtime and the required calendar contracts being implemented. The original supplied prompt below retains its wording for provenance.

> This is a future implementation task. The supplied prompt is preserved below; the integration requirements add the decisions and evidence needed to accept it. This documentation does not indicate that the phase has been implemented or measured.

## QA and JEV instructions

Prepend this addendum to the original phase prompt below:

```text
Read docs/calendar/QA-REVIEW.md, docs/calendar/INTEGRATION-GATES.md and
docs/calendar/JEV.md alongside docs/calendar/BRIEF.md.
Apply docs/calendar/PERFORMANCE.md. Akira tools reuse the same queries/mutations and preserve pending versus confirmed outcomes. Measure optional AI full-path latency/cost, including fallback; core calendar gates must pass with AI off, slow and erroring.
Apply J01 only at the calendar-local routing seam and only in shadow mode initially. Reuse the verified server-side Decisions pattern without adding a duplicate global outcome router. Preserve five tool names and argument contracts; route compound/unknown requests through the approved baseline planner once Akira is implemented. Validate targets, dates, ownership, scope and intent independently before mutation. Establish the working baseline first, then report routing benefit against it.
```

The [QA review](/guides/open-work/roadmap/calendar-view/qa-review) and [Akira JEV assessment](/guides/open-work/roadmap/akira/jev) are included in the handoff bundle. The original prompt remains verbatim.

## Paste-ready phase prompt

```text
Expose the calendar to Akira through @tanstack/ai.
Tools (client-side, so the UI reacts in the same tick):
- list_events({ from, to }): reads eventsCollection, returns compact rows.
- find_availability({ emails, from, to, durationMin }): calls POST /calendar/availability.
- create_event({ title, start, end, attendees, calendarId }): uses the Phase 4 insert mutation.
- move_event({ id, start, end, scope }): uses the update mutation and the scope rules.
- focus_range({ from, to }): navigates the grid and highlights the range.
When a tool creates or moves an event, the affected chip gets the selection ring and the agenda
scrolls to it. Tool definitions carry the JSON schema for arguments; validate with zod before
executing. Read the existing Akira tool registration pattern first and match it exactly.
Definition of done:
- A scripted conversation test: "find 30 minutes with <email> next week and book it" results
  in one availability call, one insert, and the chip visible in the grid.
- Tools appear in the Akira tool list with descriptions that a non-engineer would understand.
```

## Integration requirements

- After Akira is implemented, inspect and match its actual registration pattern. Preserve the five tool names and the supplied argument shapes; map them explicitly into approved mutation DTOs rather than creating a second write path.
- `list_events` must distinguish complete loaded coverage from a partial local result. Availability belongs to the backend contract and must follow the agreed all-provider-calls-in-Drain design.
- Validate arguments before execution. A request to find a free slot does not itself authorize booking; the supplied scripted test includes explicit booking intent.
- Exercise tools against fixtures and mocks for this phase. Test read-only, recurring scope, failed mutation and repeated tool execution as well as the happy path. Capture the resulting UI state in both viewport sizes/themes and name one removed element.

Read the related gates: [G02](/guides/open-work/roadmap/calendar-view/integration-gates#g02), [G05](/guides/open-work/roadmap/calendar-view/integration-gates#g05), [G06](/guides/open-work/roadmap/calendar-view/integration-gates#g06), [G09](/guides/open-work/roadmap/calendar-view/integration-gates#g09), [G11](/guides/open-work/roadmap/calendar-view/integration-gates#g11).

## Acceptance evidence

Argument-validation tests, scripted conversation with one availability call and one insert, tool descriptions, mutation reuse evidence, UI screenshots and removal critique.

[Phase 5](/guides/open-work/roadmap/calendar-view/frontend/phase-5) · [Phase 7](/guides/open-work/roadmap/calendar-view/frontend/phase-7)


---

# Calendar View — Phase 7: Performance pass and critique

[Phase 6](/guides/open-work/roadmap/calendar-view/frontend/phase-6) · [Calendar View](/guides/open-work/roadmap/calendar-view) · [Integration gates](/guides/open-work/roadmap/calendar-view/integration-gates)

Measure every calendar performance gate and complete the final visual review with raw before-and-after evidence.

> This is a future implementation task. The supplied prompt is preserved below; the integration requirements add the decisions and evidence needed to accept it. This documentation does not indicate that the phase has been implemented or measured.

## QA and JEV instructions

Prepend this addendum to the original phase prompt below:

```text
Read docs/calendar/QA-REVIEW.md, docs/calendar/INTEGRATION-GATES.md and
docs/calendar/JEV.md alongside docs/calendar/BRIEF.md.
Read docs/calendar/PERFORMANCE.md. Run its effective nine-slot matrix (month paging replaces source slot 5), P01-P08 and applicable picker/pilot gates. Report raw samples, p50/p95/max, traces, query plans, requests, memory and total incremental bytes; required failures or missing measurements block acceptance.
Report J01 and J02 independently as adopt, defer or reject after their own held-out evaluation. Show precision, coverage, failures, uncertainty, p50/p95 latency and full-path cost including fallback. Synthetic responses are not results. Run the effective nine-slot calendar matrix (PERFORMANCE.md replaces the month-scroll slot) with pilots off and, for any proposed enabled mode, on/erroring. Do not make core release depend on an optional pilot.
```

The [QA review](/guides/open-work/roadmap/calendar-view/qa-review) and [Akira JEV assessment](/guides/open-work/roadmap/akira/jev) are included in the handoff bundle. The original prompt remains verbatim.

## Paste-ready phase prompt

```text
Run every gate in section 5.2 against a production build with 4x CPU throttle. For each failing
gate, profile, fix, and re-measure. Do not touch behavior.
Then review all screenshots from phases 2 to 5 as a design lead would: list five things that
read as generic or templated and fix the three that matter most. Name what you removed.
Final report: table of gates with before and after numbers, the list of design changes, and
any API gaps carried forward.
```

## Integration requirements

- Use the production build, fixed 5,000-event fixture and the recorded 4× CPU throttle setup. Report all nine slots using PERFORMANCE.md for the month-paging replacement, plus P01–P08, with raw values, units, measured intervals and pass/fail/not-run results.
- Keep the 40-overlap packing case and 500-row agenda case reproducible. Report missing measurements as not run, and unresolved failures as failures.
- Review screenshots from phases 2–5, identify five concrete visual issues and fix the three that matter most. Recapture affected views at both required sizes and themes; name what was removed.
- Carry unresolved API, provider, cursor and accessibility gaps into the final report. A fast fixture build does not prove live-provider correctness or complete backend integration.

Read the related gates: [G04](/guides/open-work/roadmap/calendar-view/integration-gates#g04), [G08](/guides/open-work/roadmap/calendar-view/integration-gates#g08), [G10](/guides/open-work/roadmap/calendar-view/integration-gates#g10), [G11](/guides/open-work/roadmap/calendar-view/integration-gates#g11).

## Acceptance evidence

Before/after table for the effective nine-slot matrix and P01–P08, raw samples and traces, bundle/heap/query analysis, fixture/environment manifest, final screenshots, design changes and explicit carried-forward gaps.

[Phase 6](/guides/open-work/roadmap/calendar-view/frontend/phase-6) · [Integration gates](/guides/open-work/roadmap/calendar-view/integration-gates)
