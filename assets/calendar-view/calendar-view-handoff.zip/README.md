# Calendar View handoff

Build plan only, for the implementing agent. No application implementation,
provider invitation or passing performance benchmark is supplied by this bundle.
Akira is spec only, not implemented; core calendar behavior is independent.

Copy frontend/docs/calendar/ together. Start with BRIEF.md, QA-REVIEW.md and
INTEGRATION-GATES.md, then NAVIGATION-AND-CACHE.md, AGENDA-AND-SCHEDULING.md and
PERFORMANCE.md. The dated addenda take precedence where they explicitly replace
source requirements. Read PHASE-PROMPTS.md for all eight phases and their current
additions; do not run only the preserved original prompts.

Current decisions: no-scroll month paging; context-rich agenda List plus visual
Timeline; shared 60-day forward event cache and resumable updates; Cmd-K and
icon navigation plus 0 / 0 0 shortcuts; manual or fuzzy-search guest selection;
real Nylas event/invitation delivery after authorized provider confirmation.
PERFORMANCE.md defines the effective nine-slot matrix and P01-P08 gates.
Implementation must report raw measurements; unknown or failed gates do not pass.

The three calendar-mirror files and reference/calendar-frontend-agent-brief.md
preserve supplied source exactly, including known defects. Do not deploy them
unchanged. BRIEF.md preserves sections 1-6 after an editorial preamble.

NL-DATE-PICKER.md specifies shared manual/natural-language input and optional
J03. JEV.md covers optional Akira J01/J02 pilots. All are unmeasured and gated;
jev-examples.json contains synthetic examples, not live model results.

Canonical Mintlify pages:
- /guides/open-work/roadmap/calendar-view
- /guides/open-work/roadmap/calendar-view/navigation-and-cache
- /guides/open-work/roadmap/calendar-view/agenda-and-scheduling
- /guides/open-work/roadmap/calendar-view/performance
- /guides/open-work/roadmap/akira

Multiple-account decisions are confirmed: the left-panel Calendar account
selector displays email/provider and switches visible events plus the default
account for new meetings. Each account has a reviewed writable calendar
destination. FREE / OPEN checks every calendar selected for availability across
connected accounts, including those hidden from the active account's view.
Existing drafts/events retain their original identity. Switching a connected
account is local and does not reset the shared store/stream.

The plan is ready for Phase 0. Technical contract, provider-command, permission,
coverage/cursor and benchmark decisions remain explicit implementation gates;
see the readiness register in INTEGRATION-GATES.md. No further product question
from this review is pending.
